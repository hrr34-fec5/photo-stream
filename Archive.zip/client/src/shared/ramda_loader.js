export const append = require('ramda/src/append');
export const assoc = require('ramda/src/assoc');
export const curry = require('ramda/src/curry');
export const equals = require('ramda/src/equals');
export const keys = require('ramda/src/keys');
export const last = require('ramda/src/last');
export const reduce = require('ramda/src/reduce');
export const union = require('ramda/src/union');

